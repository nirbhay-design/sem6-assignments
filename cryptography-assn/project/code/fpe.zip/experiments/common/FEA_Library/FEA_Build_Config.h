﻿#pragma once
#ifndef FEA_BUILD_CONFIG_H
#define FEA_BUILD_CONFIG_H

/**
 * @file FEA_Build_Config.h
 */

//#define FEA_MODULE_TRANSFORM
#define FEA_MODULE_BLKENC


#endif